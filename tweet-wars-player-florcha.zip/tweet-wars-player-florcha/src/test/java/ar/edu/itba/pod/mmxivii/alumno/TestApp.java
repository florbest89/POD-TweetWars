package ar.edu.itba.pod.mmxivii.alumno;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class TestApp
{
	@Test public void test()
	{
		assertThat(true).isTrue();
	}
}
